const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();

exports.main = async (event) => {
  const { postId, content, author } = event;

  await db.collection('comments').add({
    data: {
      postId,
      content,
      author,
      createTime: db.serverDate()
    }
  });

  await db.collection('posts').doc(postId).update({
    data: { commentCount: db.command.inc(1) }
  });

  return { success: true };
};
