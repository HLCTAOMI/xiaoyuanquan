// 云函数入口文件
const cloud = require('wx-server-sdk')
const crypto = require('crypto')

cloud.init({
    env: cloud.DYNAMIC_CURRENT_ENV
}) // 使用当前云环境

const db = cloud.database()

// 密码加密函数
function encryptPassword(password) {
    return crypto.createHash('sha256').update(password).digest('hex')
}

// 注册功能
async function register(event) {
    const { username, password, nickName } = event
    const encryptedPassword = encryptPassword(password)

    try {
        // 检查用户名是否已存在
        const existUser = await db.collection('users')
            .where({
                username: username
            })
            .get()

        if (existUser.data.length > 0) {
            return {
                code: 1,
                message: '用户名已存在'
            }
        }

        // 创建新用户
        const result = await db.collection('users').add({
            data: {
                username: username,
                password: encryptedPassword,
                nickName: nickName || username,
                createTime: db.serverDate(),
                updateTime: db.serverDate(),
                lastLoginTime: db.serverDate(),
                loginCount: 1
            }
        })

        return {
            code: 0,
            message: '注册成功',
            data: {
                _id: result._id,
                username: username,
                nickName: nickName || username
            }
        }
    } catch (err) {
        console.error('注册失败:', err)
        return {
            code: 1,
            message: '注册失败，请稍后重试'
        }
    }
}

// 登录功能
async function login(event) {
    const { username, password } = event
    const encryptedPassword = encryptPassword(password)

    try {
        // 先检查是否是管理员
        const admin = await db.collection('admin')
            .where({
                username: username,
                password: encryptedPassword
            })
            .get()

        if (admin.data.length > 0) {
            // 更新管理员登录信息
            await db.collection('admin')
                .doc(admin.data[0]._id)
                .update({
                    data: {
                        lastLoginTime: db.serverDate(),
                        loginCount: db.command.inc(1),
                        updateTime: db.serverDate()
                    }
                })

            // 登录成功，返回管理员信息（不包含密码）
            const adminInfo = admin.data[0]
            delete adminInfo.password
            adminInfo.isAdmin = true

            return {
                code: 0,
                message: '管理员登录成功',
                data: adminInfo
            }
        }

        // 如果不是管理员，检查普通用户
        const user = await db.collection('users')
            .where({
                username: username,
                password: encryptedPassword
            })
            .get()

        if (user.data.length === 0) {
            return {
                code: 1,
                message: '账号或密码错误'
            }
        }

        // 更新登录信息
        await db.collection('users')
            .doc(user.data[0]._id)
            .update({
                data: {
                    lastLoginTime: db.serverDate(),
                    loginCount: db.command.inc(1),
                    updateTime: db.serverDate()
                }
            })

        // 登录成功，返回用户信息（不包含密码）
        const userInfo = user.data[0]
        delete userInfo.password
        userInfo.isAdmin = false

        return {
            code: 0,
            message: '登录成功',
            data: userInfo
        }
    } catch (err) {
        console.error('登录失败:', err)
        return {
            code: 1,
            message: '登录失败，请稍后重试'
        }
    }
}

// 修改密码功能
async function changePassword(event) {
    const { username, oldPassword, newPassword } = event
    const encryptedOldPassword = encryptPassword(oldPassword)
    const encryptedNewPassword = encryptPassword(newPassword)

    try {
        // 验证原密码
        const user = await db.collection('users')
            .where({
                username: username,
                password: encryptedOldPassword
            })
            .get()

        if (user.data.length === 0) {
            return {
                code: 1,
                message: '原密码错误'
            }
        }

        // 更新密码
        await db.collection('users')
            .doc(user.data[0]._id)
            .update({
                data: {
                    password: encryptedNewPassword,
                    updateTime: db.serverDate()
                }
            })

        return {
            code: 0,
            message: '密码修改成功'
        }
    } catch (err) {
        console.error('修改密码失败:', err)
        return {
            code: 1,
            message: '修改密码失败，请稍后重试'
        }
    }
}

// 云函数入口函数
exports.main = async (event, context) => {
    const { action } = event

    switch (action) {
        case 'register':
            return await register(event)
        case 'login':
            return await login(event)
        case 'changePassword':
            return await changePassword(event)
        default:
            return {
                code: 1,
                message: '未知的操作类型'
            }
    }
}