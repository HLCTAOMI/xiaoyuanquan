// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

// 云函数入口函数
exports.main = async (event, context) => {
  try {
    const result = await db.collection('lost_and_found')
      .orderBy('createTime', 'desc')
      .get()

    return {
      code: 0,
      data: result.data
    }
  } catch (error) {
    return {
      code: -1,
      error: error.message
    }
  }
} 