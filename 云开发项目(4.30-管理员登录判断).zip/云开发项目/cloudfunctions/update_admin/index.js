// 云函数入口文件
const cloud = require('wx-server-sdk')
const crypto = require('crypto')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
}) // 使用当前云环境

const db = cloud.database()

// 密码加密函数
function encryptPassword(password) {
  return crypto.createHash('sha256').update(password).digest('hex')
}

// 云函数入口函数
exports.main = async (event, context) => {
  try {
    const { _id, updateData } = event
    const { username, password } = updateData.$set

    // 如果更新了密码，需要加密
    if (password) {
      updateData.$set.password = encryptPassword(password)
    }

    // 更新管理员信息
    const result = await db.collection('admin')
      .doc(_id)
      .update({
        data: updateData
      })

    return {
      code: 0,
      message: '更新成功',
      data: result
    }
  } catch (err) {
    console.error('更新管理员失败:', err)
    return {
      code: 1,
      message: '更新失败，请稍后重试'
    }
  }
}