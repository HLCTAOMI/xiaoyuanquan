const app = getApp()

Page({
    data: {
        lostItems: [],
        statusArray: ['全部', '已找到', '未找到'],
        typeArray: ['全部', '失物', '招领'],
        statusIndex: 0,
        typeIndex: 0,
        showModal: false,
        isEdit: false,
        formData: {
            id: '',
            title: '',
            description: '',
            statusIndex: 1,
            typeIndex: 1
        },
        searchKeyword: '',
        page: 1,
        pageSize: 10,
        total: 0,
        loading: false
    },

    onLoad() {
        this.loadLostItems()
    },

    // 加载失物招领列表
    async loadLostItems() {
        try {
            const result = await wx.cloud.callFunction({
                name: 'manageLostAndFound'
            })

            if (result.result.code === 0) {
                const formattedList = result.result.data.map(item => ({
                    ...item,
                    createTime: this.formatTime(item.createTime)
                }))
                this.setData({
                    lostItems: formattedList
                })
            }
        } catch (error) {
            console.error('加载数据失败:', error)
        }
    },

    // 格式化时间
    formatTime(date) {
        if (!date) return ''
        const d = new Date(date)
        const year = d.getFullYear()
        const month = (d.getMonth() + 1).toString().padStart(2, '0')
        const day = d.getDate().toString().padStart(2, '0')
        const hour = d.getHours().toString().padStart(2, '0')
        const minute = d.getMinutes().toString().padStart(2, '0')
        return `${year}-${month}-${day} ${hour}:${minute}`
    },

    // 搜索处理
    onSearch(e) {
        this.setData({
            searchKeyword: e.detail.value,
            page: 1
        }, () => {
            this.loadLostItems()
        })
    },

    // 状态筛选
    onStatusChange(e) {
        this.setData({
            statusIndex: e.detail.value,
            page: 1
        }, () => {
            this.loadLostItems()
        })
    },

    // 类型筛选
    onTypeChange(e) {
        this.setData({
            typeIndex: e.detail.value,
            page: 1
        }, () => {
            this.loadLostItems()
        })
    },

    // 显示添加模态框
    showAddModal() {
        this.setData({
            showModal: true,
            isEdit: false,
            formData: {
                id: '',
                title: '',
                description: '',
                statusIndex: 1,
                typeIndex: 1
            }
        })
    },

    // 显示编辑模态框
    editItem(e) {
        const id = e.currentTarget.dataset.id
        const item = this.data.lostItems.find(item => item._id === id)
        if (item) {
            this.setData({
                showModal: true,
                isEdit: true,
                formData: {
                    id: item._id,
                    title: item.title,
                    description: item.description,
                    statusIndex: item.status === '已找到' ? 1 : 2,
                    typeIndex: item.type === '失物' ? 1 : 2
                }
            })
        }
    },

    // 隐藏模态框
    hideModal() {
        this.setData({
            showModal: false
        })
    },

    // 表单输入处理
    onTitleInput(e) {
        this.setData({
            'formData.title': e.detail.value
        })
    },

    onDescInput(e) {
        this.setData({
            'formData.description': e.detail.value
        })
    },

    onFormStatusChange(e) {
        this.setData({
            'formData.statusIndex': e.detail.value
        })
    },

    onFormTypeChange(e) {
        this.setData({
            'formData.typeIndex': e.detail.value
        })
    },

    // 提交表单
    async submitForm() {
        const { title, description, statusIndex, typeIndex, id } = this.data.formData
        if (!title || !description) {
            wx.showToast({
                title: '请填写完整信息',
                icon: 'none'
            })
            return
        }

        try {
            const db = wx.cloud.database()
            const status = this.data.statusArray[statusIndex]
            const type = this.data.typeArray[typeIndex]

            if (this.data.isEdit) {
                // 更新数据
                await db.collection('lost_and_found').doc(id).update({
                    data: {
                        title,
                        description,
                        status,
                        type,
                        updateTime: db.serverDate()
                    }
                })
            } else {
                // 添加数据
                await db.collection('lost_and_found').add({
                    data: {
                        title,
                        description,
                        status,
                        type,
                        createTime: db.serverDate(),
                        updateTime: db.serverDate()
                    }
                })
            }

            wx.showToast({
                title: '提交成功',
                icon: 'success'
            })
            this.hideModal()
            this.loadLostItems()
        } catch (error) {
            console.error('提交失败:', error)
            wx.showToast({
                title: '提交失败',
                icon: 'none'
            })
        }
    },

    // 删除项目
    async deleteItem(e) {
        const id = e.currentTarget.dataset.id
        wx.showModal({
            title: '确认删除',
            content: '确定要删除这条记录吗？',
            success: async (res) => {
                if (res.confirm) {
                    try {
                        const db = wx.cloud.database()
                        await db.collection('lost_and_found').doc(id).remove()

                        wx.showToast({
                            title: '删除成功',
                            icon: 'success'
                        })
                        this.loadLostItems()
                    } catch (error) {
                        console.error('删除失败:', error)
                        wx.showToast({
                            title: '删除失败',
                            icon: 'none'
                        })
                    }
                }
            }
        })
    },

    // 下拉刷新
    onPullDownRefresh() {
        this.setData({
            page: 1
        }, () => {
            this.loadLostItems().then(() => {
                wx.stopPullDownRefresh()
            })
        })
    },

    // 上拉加载更多
    onReachBottom() {
        const { page, total, pageSize } = this.data
        if (page * pageSize < total) {
            this.setData({
                page: page + 1
            }, () => {
                this.loadLostItems()
            })
        }
    }
}) 