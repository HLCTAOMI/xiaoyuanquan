// pages/lost/lost-found/lost-found.js
const app = getApp()

Page({

    /**
     * 页面的初始数据
     */
    data: {
        list: [], // 用户发布的失物招领列表
        page: 1,
        pageSize: 10,
        total: 0,
        loading: false,
        hasMore: true,
        needRefresh: false,
        isLoggedIn: false,
        userInfo: null
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        // 检查登录状态
        this.checkLoginStatus()
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
        // 检查是否需要刷新
        if (this.data.needRefresh) {
            this.setData({
                page: 1,
                list: [],
                hasMore: true,
                needRefresh: false
            });
            this.getMyLostFoundList();
        }
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {
        this.setData({
            page: 1,
            list: [],
            hasMore: true
        })
        this.getMyLostFoundList().then(() => {
            wx.stopPullDownRefresh()
        })
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {
        if (this.data.hasMore && !this.data.loading) {
            this.getMyLostFoundList(true)
        }
    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    },

    // 检查登录状态
    checkLoginStatus() {
        const userInfo = app.globalData.userInfo || wx.getStorageSync('userInfo')
        if (userInfo) {
            this.setData({
                isLoggedIn: true,
                userInfo: userInfo
            })
            // 获取失物招领列表
            this.getMyLostFoundList()
        } else {
            this.setData({
                isLoggedIn: false,
                userInfo: null
            })
        }
    },

    // 获取用户发布的失物招领列表
    async getMyLostFoundList(isLoadMore = false) {
        if (this.data.loading) return
        
        this.setData({ loading: true })

        try {
            const { result } = await wx.cloud.callFunction({
                name: 'lostAndFound',
                data: {
                    action: 'getMyList',
                    data: {
                        page: this.data.page,
                        pageSize: this.data.pageSize,
                        userId: this.data.userInfo._id,
                        isAdmin: this.data.userInfo.isAdmin
                    }
                }
            })

            if (result.code === 0) {
                const { list, total } = result.data
                const newList = isLoadMore ? [...this.data.list, ...list] : list
                
                this.setData({
                    list: newList,
                    total,
                    hasMore: newList.length < total,
                    page: isLoadMore ? this.data.page + 1 : 1
                })

                // 如果列表为空，显示提示
                if (newList.length === 0) {
                    wx.showToast({
                        title: '暂无失物招领信息',
                        icon: 'none'
                    })
                }
            } else {
                throw new Error(result.message || '获取数据失败')
            }
        } catch (error) {
            wx.showToast({
                title: error.message || '获取数据失败',
                icon: 'none'
            })
        } finally {
            this.setData({ loading: false })
        }
    },

    // 删除失物招领信息
    async deleteLostFound(e) {
        const { id } = e.currentTarget.dataset
        
        try {
            const res = await wx.showModal({
                title: '提示',
                content: '确定要删除这条信息吗？',
                confirmText: '删除'
            })

            if (res.confirm) {
                const { result } = await wx.cloud.callFunction({
                    name: 'lostAndFound',
                    data: {
                        action: 'delete',
                        data: { id }
                    }
                })

                if (result.code === 0) {
                    wx.showToast({
                        title: '删除成功',
                        icon: 'success'
                    })
                    // 重新加载列表
                    this.setData({ page: 1, list: [], hasMore: true })
                    this.getMyLostFoundList()
                } else {
                    throw new Error(result.message || '删除失败')
                }
            }
        } catch (error) {
            wx.showToast({
                title: error.message || '删除失败',
                icon: 'none'
            })
        }
    },

    // 编辑失物招领信息
    editLostFound(e) {
        const { id } = e.currentTarget.dataset
        wx.navigateTo({
            url: `/pages/lost/publish/publish?id=${id}&isEdit=true`
        })
    },

    // 查看详情
    viewDetail(e) {
        const { id } = e.currentTarget.dataset
        wx.navigateTo({
            url: `/pages/lost/lostdetail/lostdetail?id=${id}`
        })
    },

    // 发布新的失物招领
    goToPublish() {
        wx.navigateTo({
            url: '/pages/lost/publish/publish'
        })
    },
    goToLogin() {
      wx.navigateTo({
          url: '/pages/more/login/login'
      })
  },

    // 预览图片
    previewImage(e) {
        const { current, urls } = e.currentTarget.dataset
        wx.previewImage({
            current,
            urls
        })
    },

    // 处理图片加载错误
    handleImageError(e) {
        const { index } = e.currentTarget.dataset
        const list = this.data.list
        list[index].images = ['/images/default_item.png']
        this.setData({ list })
    }
})