Page({
  data: {
    list: [], // 所有失物信息
    activeType: 'all', // 当前筛选类型
    filterType: 'all', // 过滤后类型
    page: 1,
    pageSize: 10,
    total: 0,
    loading: false,
    hasMore: true,
    defaultImage: '/images/default_item.png'  // 添加默认图片路径
  },

  // 生命周期：页面加载时获取数据
  onLoad() {
    this.fetchLostAndFoundList();
  },

  // 下拉刷新
  onPullDownRefresh() {
    this.setData({
      page: 1,
      list: [],
      hasMore: true
    });
    this.fetchLostAndFoundList().then(() => {
      wx.stopPullDownRefresh();
    });
  },

  // 上拉加载更多
  onReachBottom() {
    if (this.data.hasMore && !this.data.loading) {
      this.fetchLostAndFoundList(true);
    }
  },

  // 获取失物信息列表
  async fetchLostAndFoundList(isLoadMore = false) {
    if (this.data.loading) return;
    
    this.setData({ loading: true });

    try {
      const res = await wx.cloud.callFunction({
        name: 'lostAndFound',
        data: {
          action: 'getList',
          data: {
            type: this.data.filterType,
            page: this.data.page,
            pageSize: this.data.pageSize
          }
        }
      });

      if (res.result.code === 0) {
        const { list, total } = res.result.data;
        const newList = isLoadMore ? [...this.data.list, ...list] : list;
        
        this.setData({
          list: newList,
          total,
          hasMore: newList.length < total,
          page: isLoadMore ? this.data.page + 1 : 1,
          loading: false
        });
      } else {
        throw new Error(res.result.message || '获取数据失败');
      }
    } catch (error) {
      wx.showToast({
        title: error.message || '获取数据失败，请检查网络连接',
        icon: 'none',
        duration: 2000
      });
      this.setData({ loading: false });
    }
  },

  // 筛选类型
  filterType(e) {
    const type = e.currentTarget.dataset.type;
    this.setData({
      activeType: type,
      filterType: type,
      page: 1,
      list: [],
      hasMore: true
    });
    this.fetchLostAndFoundList();
  },

  // 跳转发布页面
  goToPublish() {
    wx.navigateTo({
      url: '/pages/lost/publish/publish'
    });
  },

  // 查看详情
  viewDetails(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/lost/lostdetail/lostdetail?id=${id}`
    });
  },

  // 预览图片
  previewImage(e) {
    const { current, urls } = e.currentTarget.dataset;
    wx.previewImage({
      current,
      urls
    });
  },

  // 格式化日期
  formatDate(date) {
    return new Date(date).toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    });
  },

  handleImageError: function(e) {
    const index = e.currentTarget.dataset.index;
    const item = this.data.list[index];
    
    // 如果图片加载失败，尝试重新获取临时链接
    if (item && item.fileID) {
      wx.cloud.getTempFileURL({
        fileList: [item.fileID],
        success: res => {
          if (res.fileList && res.fileList[0] && res.fileList[0].tempFileURL) {
            // 更新临时链接
            const newList = [...this.data.list];
            newList[index].images[0] = res.fileList[0].tempFileURL;
            this.setData({
              list: newList
            });
          } else {
            // 如果获取失败，使用默认图片
            const newList = [...this.data.list];
            newList[index].images[0] = this.data.defaultImage;
            this.setData({
              list: newList
            });
          }
        },
        fail: err => {
          console.error('获取临时链接失败:', err);
          // 使用默认图片
          const newList = [...this.data.list];
          newList[index].images[0] = this.data.defaultImage;
          this.setData({
            list: newList
          });
        }
      });
    } else {
      // 如果没有 fileID，直接使用默认图片
      const newList = [...this.data.list];
      newList[index].images[0] = this.data.defaultImage;
      this.setData({
        list: newList
      });
    }
  },

  getList: function() {
    if (this.data.loading || !this.data.hasMore) return;
    
    this.setData({ loading: true });
    
    const db = wx.cloud.database();
    const _ = db.command;
    let query = {};
    
    if (this.data.filterType !== 'all') {
      query.type = this.data.filterType;
    }
    
    db.collection('lost_found')
      .where(query)
      .orderBy('createTime', 'desc')
      .skip(this.data.list.length)
      .limit(10)
      .get()
      .then(res => {
        if (res.data.length === 0) {
          this.setData({
            hasMore: false,
            loading: false
          });
          return;
        }

        // 获取所有图片的临时链接
        const fileIDs = res.data
          .filter(item => item.images && item.images.length > 0)
          .map(item => item.images[0]);

        if (fileIDs.length > 0) {
          wx.cloud.getTempFileURL({
            fileList: fileIDs,
            success: urlRes => {
              const urlMap = {};
              urlRes.fileList.forEach(file => {
                urlMap[file.fileID] = file.tempFileURL;
              });

              // 更新图片链接
              const newData = res.data.map(item => {
                if (item.images && item.images.length > 0) {
                  const fileID = item.images[0];
                  item.images[0] = urlMap[fileID] || this.data.defaultImage;
                  item.fileID = fileID; // 保存 fileID 以便后续刷新
                }
                return item;
              });

              this.setData({
                list: this.data.list.concat(newData),
                loading: false
              });
            },
            fail: err => {
              console.error('获取临时链接失败:', err);
              // 使用默认图片
              const newData = res.data.map(item => {
                if (item.images && item.images.length > 0) {
                  const fileID = item.images[0];
                  item.images[0] = this.data.defaultImage;
                  item.fileID = fileID;
                }
                return item;
              });

              this.setData({
                list: this.data.list.concat(newData),
                loading: false
              });
            }
          });
        } else {
          // 没有图片的情况
          this.setData({
            list: this.data.list.concat(res.data),
            loading: false
          });
        }
      })
      .catch(err => {
        console.error('获取列表失败:', err);
        this.setData({ loading: false });
        wx.showToast({
          title: '获取数据失败',
          icon: 'none'
        });
      });
  },

  // 点击跳转到详情页
  goToDetail(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/lost/lostdetail/lostdetail?id=${id}`
    });
  },

  // 处理图片加载
  handleImageLoad(e) {
    const index = e.currentTarget.dataset.index;
    const list = this.data.list;
    list[index].imageLoaded = true;
    this.setData({ list });
  }
});