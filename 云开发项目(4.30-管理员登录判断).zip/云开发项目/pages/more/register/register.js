Page({
  data: {
    username: '',
    password: '',
    confirmPassword: '',
    nickName: ''
  },

  // 输入用户名
  onInputUsername(e) {
    this.setData({
      username: e.detail.value
    });
  },

  // 输入密码
  onInputPassword(e) {
    this.setData({
      password: e.detail.value
    });
  },

  // 输入确认密码
  onInputConfirmPassword(e) {
    this.setData({
      confirmPassword: e.detail.value
    });
  },

  // 输入昵称
  onInputNickname(e) {
    this.setData({
      nickName: e.detail.value
    });
  },

  // 确认注册
  async confirmRegister() {
    const { username, password, confirmPassword, nickName } = this.data;
    
    // 表单验证
    if (!username || !password || !confirmPassword) {
      wx.showToast({
        title: '请填写完整信息',
        icon: 'none'
      });
      return;
    }

    if (password !== confirmPassword) {
      wx.showToast({
        title: '两次输入的密码不一致',
        icon: 'none'
      });
      return;
    }

    if (password.length < 6) {
      wx.showToast({
        title: '密码长度不能少于6位',
        icon: 'none'
      });
      return;
    }

    wx.showLoading({
      title: '注册中...'
    });

    try {
      const res = await wx.cloud.callFunction({
        name: 'login',
        data: {
          action: 'register',
          username,
          password,
          nickName
        }
      });

      if (res.result.code === 0) {
        wx.showToast({
          title: '注册成功',
          icon: 'success'
        });

        // 注册成功后自动登录
        setTimeout(() => {
          wx.navigateBack();
        }, 1500);
      } else {
        throw new Error(res.result.message || '注册失败');
      }
    } catch (error) {
      console.error('注册失败:', error);
      wx.showToast({
        title: error.message || '注册失败',
        icon: 'none'
      });
    } finally {
      wx.hideLoading();
    }
  },

  // 跳转到登录页面
  goToLogin() {
    wx.navigateBack();
  }
}); 