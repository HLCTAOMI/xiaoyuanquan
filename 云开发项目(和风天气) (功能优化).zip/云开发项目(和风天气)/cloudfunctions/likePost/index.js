const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();

exports.main = async (event) => {
  const { postId, userOpenid } = event;
  const likeRef = db.collection('likes');

  const hasLiked = await likeRef.where({ postId, userOpenid }).get();

  if (hasLiked.data.length > 0) {
    // 已点赞 -> 取消点赞
    await likeRef.where({ postId, userOpenid }).remove();
    await db.collection('posts').doc(postId).update({
      data: { likeCount: db.command.inc(-1) }
    });
    return { liked: false };
  } else {
    // 未点赞 -> 点赞
    await likeRef.add({ data: { postId, userOpenid } });
    await db.collection('posts').doc(postId).update({
      data: { likeCount: db.command.inc(1) }
    });
    return { liked: true };
  }
};
