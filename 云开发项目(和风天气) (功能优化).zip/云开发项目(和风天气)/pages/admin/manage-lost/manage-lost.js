// pages/lost/lost-found/lost-found.js
const app = getApp()

Page({

    /**
     * 页面的初始数据
     */
    data: {
        list: [], // 失物招领列表
        page: 1,
        pageSize: 10,
        total: 0,
        loading: false,
        hasMore: true,
        needRefresh: false,
        userInfo: null
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        // 检查登录状态
        this.checkLoginStatus()
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
        // 每次显示页面时重新检查登录状态
        this.checkLoginStatus()
        
        if (this.data.needRefresh) {
            this.setData({
                page: 1,
                list: [],
                hasMore: true,
                needRefresh: false
            });
            this.getLostFoundList();
        }
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {
        this.setData({
            page: 1,
            list: [],
            hasMore: true
        })
        this.getLostFoundList().then(() => {
            wx.stopPullDownRefresh()
        })
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {
        if (this.data.hasMore && !this.data.loading) {
            this.getLostFoundList(true)
        }
    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    },

    // 检查登录状态
    checkLoginStatus() {
        const app = getApp()
        const userInfo = app.userInfo
        
        if (userInfo && userInfo.userinfo) {
            this.setData({ userInfo })
            this.getLostFoundList()
        } else {
            wx.showToast({
                title: '请先登录',
                icon: 'none'
            })
            setTimeout(() => {
                wx.navigateBack()
            }, 1500)
        }
    },

    // 获取所有失物招领列表
    async getLostFoundList(isLoadMore = false) {
        if (this.data.loading) return
        
        this.setData({ loading: true })

        try {
            const { result } = await wx.cloud.callFunction({
                name: 'lostAndFound',
                data: {
                    action: 'getAllList',
                    data: {
                        page: this.data.page,
                        pageSize: this.data.pageSize
                    }
                }
            })

            if (result.code === 0) {
                const { list, total } = result.data
                const newList = isLoadMore ? [...this.data.list, ...list] : list
                
                this.setData({
                    list: newList,
                    total,
                    hasMore: newList.length < total,
                    page: isLoadMore ? this.data.page + 1 : 1
                })

                if (newList.length === 0) {
                    wx.showToast({
                        title: '暂无失物招领信息',
                        icon: 'none'
                    })
                }
            } else {
                throw new Error(result.message || '获取数据失败')
            }
        } catch (error) {
            wx.showToast({
                title: error.message || '获取数据失败',
                icon: 'none'
            })
        } finally {
            this.setData({ loading: false })
        }
    },

    // 删除失物招领信息
    async deleteLostFound(e) {
        const { id } = e.currentTarget.dataset
        const app = getApp()
        
        if (!app.userInfo || !app.userInfo.userinfo) {
            wx.showToast({
                title: '请先登录',
                icon: 'none'
            })
            return
        }
        
        try {
            const res = await wx.showModal({
                title: '提示',
                content: '确定要删除这条信息吗？',
                confirmText: '删除'
            })

            if (res.confirm) {
                const { result } = await wx.cloud.callFunction({
                    name: 'lostAndFound',
                    data: {
                        action: 'delete',
                        data: { id }
                    }
                })

                if (result.code === 0) {
                    wx.showToast({
                        title: '删除成功',
                        icon: 'success'
                    })
                    this.setData({ page: 1, list: [], hasMore: true })
                    this.getLostFoundList()
                } else {
                    throw new Error(result.message || '删除失败')
                }
            }
        } catch (error) {
            wx.showToast({
                title: error.message || '删除失败',
                icon: 'none'
            })
        }
    },

    // 编辑失物招领信息
    editLostFound(e) {
        const { id } = e.currentTarget.dataset
        wx.navigateTo({
            url: `/pages/lost/publish/publish?id=${id}&isEdit=true`
        })
    },

    // 查看详情
    viewDetail(e) {
        const { id } = e.currentTarget.dataset
        wx.navigateTo({
            url: `/pages/lost/lostdetail/lostdetail?id=${id}`
        })
    },

    // 预览图片
    previewImage(e) {
        const { current, urls } = e.currentTarget.dataset
        wx.previewImage({
            current,
            urls
        })
    },

    // 处理图片加载错误
    handleImageError(e) {
        const { index } = e.currentTarget.dataset
        const list = this.data.list
        list[index].images = ['/images/default_item.png']
        this.setData({ list })
    },

    // 发布新的失物招领
    goToPublish() {
        wx.navigateTo({
            url: '/pages/lost/publish/publish'
        })
    }
})