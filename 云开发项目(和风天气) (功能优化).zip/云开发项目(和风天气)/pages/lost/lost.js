const app = getApp()

Page({
  data: {
    list: [], // 所有失物信息
    activeType: 'all', // 当前筛选类型
    filterType: 'all', // 过滤后类型
    page: 1,
    pageSize: 10,
    total: 0,
    loading: false,
    hasMore: true,
    defaultImage: '/images/default_item.png',  // 添加默认图片路径
    needRefresh: false
  },

  // 生命周期：页面加载时获取数据
  onLoad() {
    this.getLostFoundList();
  },

  onShow() {
    // 每次显示页面时都刷新数据
    this.setData({
      page: 1,
      list: [],
      hasMore: true
    });
    this.getLostFoundList();
  },

  // 下拉刷新
  onPullDownRefresh() {
    this.setData({
      page: 1,
      list: [],
      hasMore: true
    });
    this.getLostFoundList().then(() => {
      wx.stopPullDownRefresh();
    });
  },

  // 上拉加载更多
  onReachBottom() {
    if (this.data.hasMore && !this.data.loading) {
      this.getLostFoundList(true);
    }
  },

  // 获取失物信息列表
  async getLostFoundList(isLoadMore = false) {
    if (this.data.loading) return;
    
    this.setData({ loading: true });

    try {
      const { result } = await wx.cloud.callFunction({
        name: 'lostAndFound',
        data: {
          action: 'getAllList',
          data: {
            page: this.data.page,
            pageSize: this.data.pageSize,
            type: this.data.activeType === 'all' ? '' : this.data.activeType
          }
        }
      });

      if (result.code === 0) {
        const { list, total } = result.data;
        const newList = isLoadMore ? [...this.data.list, ...list] : list;
        
        this.setData({
          list: newList,
          total,
          hasMore: newList.length < total,
          page: isLoadMore ? this.data.page + 1 : 1
        });

        if (newList.length === 0) {
          wx.showToast({
            title: '暂无失物招领信息',
            icon: 'none'
          });
        }
      } else {
        throw new Error(result.message || '获取数据失败');
      }
    } catch (error) {
      wx.showToast({
        title: error.message || '获取数据失败',
        icon: 'none'
      });
    } finally {
      this.setData({ loading: false });
    }
  },

  // 筛选类型
  filterType(e) {
    const type = e.currentTarget.dataset.type;
    this.setData({
      activeType: type,
      page: 1,
      list: [],
      hasMore: true
    });
    this.getLostFoundList();
  },

  // 跳转发布页面
  goToPublish() {
    wx.navigateTo({
      url: '/pages/lost/publish/publish'
    });
  },

  // 查看详情
  goToDetail(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/lost/lostdetail/lostdetail?id=${id}`
    });
  },

  // 预览图片
  previewImage(e) {
    const { current, urls } = e.currentTarget.dataset;
    wx.previewImage({
      current,
      urls
    });
  },

  // 格式化日期
  formatDate(date) {
    if (!date) return '';
    const d = new Date(date);
    const now = new Date();
    const diff = now - d;
    
    // 小于1分钟
    if (diff < 60000) {
      return '刚刚';
    }
    // 小于1小时
    if (diff < 3600000) {
      return Math.floor(diff / 60000) + '分钟前';
    }
    // 小于24小时
    if (diff < 86400000) {
      return Math.floor(diff / 3600000) + '小时前';
    }
    // 小于30天
    if (diff < 2592000000) {
      return Math.floor(diff / 86400000) + '天前';
    }
    // 大于30天
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  },

  // 处理图片加载错误
  handleImageError(e) {
    const { index } = e.currentTarget.dataset;
    const list = this.data.list;
    if (list[index]) {
      list[index].images = [this.data.defaultImage];
      this.setData({ list });
    }
  },

  // 处理图片加载成功
  handleImageLoad(e) {
    const { index } = e.currentTarget.dataset;
    const list = this.data.list;
    if (list[index]) {
      list[index].imageLoaded = true;
      this.setData({ list });
    }
  }
});