// miniprogram/pages/wd/wd.js
const app=getApp()
const db = wx.cloud.database()
Page({
  data: {
    userphoto:"/images/user/user.png",
    username:"梦之泪伤",
    anonymous:"",
    login:"未知",
    isVIP:false,
    wenzhang:[],
    message:[],
    fenxiang:"false",
    isAdmin: false
  },
  /*这是用户授权登录向数据库提交 */
  GetUserInfo(xx){
    let userInfo = xx.detail.userInfo;
    //console.log(userInfo)
    if(!this.data.login&&userInfo){
      wx.showLoading({
        title: '登陆中',
      })
      db.collection('users').add({
        data:{
          allow:true,
          ban:false,
          msgnb:[0,0],
          online:true,
          wenzhang:[],
          message:[],
          pinglunguode:[],
          weiguinb:0,
          userinfo:{
            userphoto:userInfo.avatarUrl,
            username:userInfo.nickName,
            anonymous:"",
            isVIP:false,
            login:true,
          },
          
        }
      }).then((res)=>{
        db.collection('users').doc(res._id).get().then((res)=>{
          app.userInfo=Object.assign(app.userInfo,res.data);
          //console.log(res.data);
          wx.hideLoading()
          this.setData({
            userphoto:app.userInfo.userinfo.userphoto,
            username:app.userInfo.userinfo.username,
            anonymous:app.userInfo.userinfo.anonymous,
            isVIP:app.userInfo.userinfo.isVIP,
            login:true,
            wenzhang:app.userInfo.wenzhang,
            message:app.userInfo.message,
          })
          wx.showToast({
            title: '登陆成功！',
          })
          if(app.fenxiang=="true"){
            app.fenxiang=="false"
            wx.navigateTo({
              url:"/pages/school/plate2/plate2?id="+app.fxssid+"&fenxiang=false"
            })
          }
        })
      })
    }
  },
   /*未登录下的重试 */
  weidengluchongshi(){
    let logined=app.userInfo.userinfo.login;
    //console.log(app.userInfo);
    if(logined!=true){
      /*若不是登录状态调用云函数登录*/ 
      wx.showLoading({
        title: '尝试登录',
      })
      wx.cloud.callFunction({
        name:'login',
        data:{}
      }).then((res)=>{
        //console.log(res.result.openid)
        db.collection("users").where({_openid:app.userInfo._openid}).get().then((res)=>{
          //console.log(res);
          app.userInfo=Object.assign(app.userInfo,res.data[0]);
          if(app.userInfo.userinfo.login==true){
            /*如果有登录信息则加载*/ 
            this.setData({
              userphoto:app.userInfo.userinfo.userphoto,
              username:app.userInfo.userinfo.username,
              anonymous:app.userInfo.userinfo.anonymous,
              isVIP:app.userInfo.userinfo.isVIP,
              login:app.userInfo.userinfo.login,
              wenzhang:app.userInfo.wenzhang,
              message:app.userInfo.message,
            })
            wx.hideLoading()
            if(app.fenxiang=="true"){
              app.fenxiang=="false"
              wx.navigateTo({
                url:"/pages/school/plate2/plate2?id="+app.fxssid+"&fenxiang=false"
              })
            }
          }else{
            this.setData({
              login:false
            })
            app.userInfo.userinfo=Object.assign(app.userInfo.userinfo,{login:false})
            /*付给app下的登录状态为false*/
            wx.showToast({
              title: '还未授权登录',
              icon: 'none',
              duration: 2000,
            })
          }  
        })
      });
    }
  },
  //查看我的头像
  chakantouxiang(){
    var url=app.userInfo.userinfo.userphoto
    wx.previewImage({
      urls: [url],
    })
  },
  /**生命周期函数--监听页面加载*/
  onLoad: function () {
    this.weidengluchongshi()
  },
  /* 生命周期函数--监听页面显示*/
  onShow: function () {
    this.checkred()
    this.setData({
      userphoto:app.userInfo.userinfo.userphoto,
      username:app.userInfo.userinfo.username,
      anonymous:app.userInfo.userinfo.anonymous,
      isVIP:app.userInfo.userinfo.isVIP,
      login:app.userInfo.userinfo.login,
      wenzhang:app.userInfo.wenzhang,
      message:app.userInfo.message,
    })
  },
  
  /** 页面相关事件处理函数--监听用户下拉动作*/
  onPullDownRefresh: function () {
    if (!this.data.login) {
      wx.stopPullDownRefresh()
      wx.showToast({
        title: '请先登录',
        icon: 'none',
        duration: 800
      })
      return
    }

    var _id = app.userInfo._id
    if (!_id) {
      wx.stopPullDownRefresh()
      wx.showToast({
        title: '登录信息已失效，请重新登录',
        icon: 'none',
        duration: 800
      })
      return
    }

    db.collection('users').doc(_id).get().then((res)=>{
      console.log("取到信息",res.data)
      this.setData({
        userphoto:res.data.userinfo.userphoto,
        username:res.data.userinfo.username,
        anonymous:res.data.userinfo.anonymous,
        isVIP:res.data.userinfo.isVIP,
        login:res.data.userinfo.login,
        wenzhang:res.data.wenzhang,
        message:res.data.message,
      })
      app.userInfo=res.data
      wx.stopPullDownRefresh({})
      wx.showToast({
        title: '刷新成功',
        icon:'none',
        duration:800
      })
    }).catch(err => {
      console.error('刷新失败：', err)
      wx.stopPullDownRefresh()
      wx.showToast({
        title: '刷新失败',
        icon: 'none',
        duration: 800
      })
    })
  },
  //刷新消息红点(用于更新非tabar页面未设置的红点)
  checkred(){
  },

  // 退出登录
  logout() {
    wx.showModal({
      title: '提示',
      content: '确定要退出登录吗？',
      success: (res) => {
        if (res.confirm) {
          // 清除用户信息
          app.userInfo = {
            userinfo: {
              login: false,
              userphoto: "/images/user/user.png",
              username: "未登录",
              anonymous: "",
              isVIP: false
            }
          }
          
          // 更新页面状态
          this.setData({
            login: false,
            userphoto: "/images/user/user.png",
            username: "未登录",
            anonymous: "",
            isVIP: false,
            wenzhang: [],
            message: []
          })

          // 清除本地存储
          wx.removeStorageSync('userInfo')

          wx.showToast({
            title: '已退出登录',
            icon: 'success'
          })
        }
      }
    })
  },

  // 新的微信登录方法
  getUserProfile() {
    wx.getUserProfile({
      desc: '用于完善用户资料',
      success: (res) => {
        let userInfo = res.userInfo;
        if(!this.data.login && userInfo){
          wx.showLoading({
            title: '登录中',
          })
          // 先调用云函数获取openid
          wx.cloud.callFunction({
            name: 'login',
            data: {}
          }).then(cloudRes => {
            const openid = cloudRes.result.openid;
            // 检查是否是管理员
            db.collection('admin').where({
              _openid: openid
            }).get().then(adminRes => {
              const isAdmin = adminRes.data.length > 0;
              
              // 检查用户是否已存在
              db.collection('users').where({
                _openid: openid
              }).get().then(dbRes => {
                if(dbRes.data.length === 0) {
                  // 新用户，添加到数据库
                  db.collection('users').add({
                    data: {
                      allow: true,
                      ban: false,
                      msgnb: [0,0],
                      online: true,
                      wenzhang: [],
                      message: [],
                      pinglunguode: [],
                      weiguinb: 0,
                      userinfo: {
                        userphoto: userInfo.avatarUrl,
                        username: userInfo.nickName,
                        anonymous: "",
                        isVIP: false,
                        login: true,
                        isAdmin: isAdmin // 添加管理员标识
                      }
                    }
                  }).then(addRes => {   
                    // 获取新创建的用户信息
                    db.collection('users').doc(addRes._id).get().then(userRes => {
                      app.userInfo = Object.assign(app.userInfo, userRes.data);
                      this.updateUserInfo();
                      wx.hideLoading();
                      wx.showToast({
                        title: '登录成功！',
                        icon: 'success'
                      });
                    });
                  });
                } else {
                  // 老用户，更新信息
                  const userData = dbRes.data[0];
                  userData.userinfo.isAdmin = isAdmin; // 更新管理员标识
                  app.userInfo = Object.assign(app.userInfo, userData);
                  this.updateUserInfo();
                  wx.hideLoading();
                  wx.showToast({
                    title: '登录成功！',
                    icon: 'success'
                  });
                }
              });
            });
          });
        }
      },
      fail: (err) => {
        console.log('登录失败：', err);
        wx.showToast({
          title: '登录失败',
          icon: 'none'
        });
      }
    });
  },

  // 更新用户信息到页面
  updateUserInfo() {
    this.setData({
      userphoto: app.userInfo.userinfo.userphoto,
      username: app.userInfo.userinfo.username,
      anonymous: app.userInfo.userinfo.anonymous,
      isVIP: app.userInfo.userinfo.isVIP,
      login: true,
      wenzhang: app.userInfo.wenzhang,
      message: app.userInfo.message,
      isAdmin: app.userInfo.userinfo.isAdmin // 添加管理员状态
    });
  },

  // 检查管理员权限
  checkAdminAccess(e) {
    if (this.data.isAdmin) {
      wx.navigateTo({
        url: '/pages/admin/admin'
      })
    } else {
      wx.showModal({
        title: '提示',
        content: '您不是管理员',
        showCancel: false
      })
    }
  },
})