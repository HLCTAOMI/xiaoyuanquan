var app=getApp()
var db=wx.cloud.database()
var _=db.command
Page({

  data: {
    wenzhang:[{
      nr:"",
      id:"",
      total:"0"
    }],
    canshu:false,
    x:[],
    xx:[]
    
  },

  // 生命周期函数--监听页面加载
  onLoad: function (e) {
    var that = this
    if(e.canshu=="fabude"){
      // 从数据库获取最新数据
      db.collection('users').doc(app.userInfo._id).get().then(res => {
        var wenzhang = res.data.wenzhang || []
        var canshu = true
        var zs = wenzhang.length
        var x = []
        for(var i=0; i<zs; i++){
          x[i] = 0
        }
        that.setData({
          wenzhang: wenzhang,
          canshu: canshu,
          x: x,
          xx: x
        })
        // 更新app中的数据
        app.userInfo.wenzhang = wenzhang
      }).catch(err => {
        console.error('获取数据失败：', err)
        wx.showToast({
          title: '获取数据失败',
          icon: 'none'
        })
      })
    } else {
      // 从数据库获取最新数据
      db.collection('users').doc(app.userInfo._id).get().then(res => {
        var wenzhang = res.data.pinglunguode || []
        var canshu = false
        var zs = wenzhang.length
        var x = []
        for(var i=0; i<zs; i++){
          x[i] = 0
        }
        that.setData({
          wenzhang: wenzhang,
          canshu: canshu,
          x: x,
          xx: x
        })
        // 更新app中的数据
        app.userInfo.pinglunguode = wenzhang
      }).catch(err => {
        console.error('获取数据失败：', err)
        wx.showToast({
          title: '获取数据失败',
          icon: 'none'
        })
      })
    }
  },
  //删除自己的帖子
  delete(e){
    console.log(e.currentTarget.dataset.ssid)
    console.log(e.currentTarget.dataset.index)
    var that = this
    wx.showModal({
      title: '提示',
      content: '确认删除此帖？删除后无法恢复！',
      showCancel: true,
      confirmText: '确认删除',
      confirmColor: '#FF4D49',
      cancelText: '取消',
      cancelColor: '#000000',
      success (res) {
        if (res.confirm) {
          console.log('用户点击确定')
          var ssid = e.currentTarget.dataset.ssid
          var index = e.currentTarget.dataset.index
          
          // 先更新用户信息，移除引用
          db.collection('users').where({
            _id: app.userInfo._id
          }).update({
            data: {
              wenzhang: _.pull({
                id: _.eq(ssid)
              })
            }
          }).then(() => {
            // 尝试删除帖子（如果存在）
            return db.collection('ss').doc(ssid).get().then(res => {
              var tp = res.data.ss_xx.tp
              // 删除相关图片
              if(tp && tp.length > 0) {
                return wx.cloud.deleteFile({fileList: tp}).then(() => {
                  return db.collection('ss').doc(ssid).remove()
                })
              }
              return db.collection('ss').doc(ssid).remove()
            }).catch(err => {
              // 如果帖子不存在，继续执行
              console.log('帖子可能已被删除：', err)
              return Promise.resolve()
            })
          }).then(() => {
            // 更新本地数据
            var wenzhang = that.data.wenzhang
            wenzhang.splice(index, 1)
            var x = that.data.x
            x[index] = 0
            
            that.setData({
              wenzhang: wenzhang,
              x: x
            })
            app.userInfo.wenzhang = wenzhang
            
            wx.showToast({
              title: '删除成功',
              icon: 'none'
            })
          }).catch(err => {
            console.error('删除失败：', err)
            wx.showToast({
              title: '删除失败，请重试',
              icon: 'none'
            })
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
          wx.showToast({
            title: '取消删除',
            icon: 'none'
          })
        }
      }
    })
  },
  //删除自己的帖子
  delete1(e){
    console.log(e.currentTarget.dataset.ssid)
    console.log(e.currentTarget.dataset.index)
    var that=this
    wx.showModal({
      title: '提示',
      content: '确认删除此条记录？',
      showCancel:true,
      confirmText:'确认删除',
      confirmColor:'#FF4D49',
      cancelText:'取消',
      cancelColor:'#000000',
      success (res) {
      if (res.confirm) {
        console.log('用户点击确定')
        var ssid=e.currentTarget.dataset.ssid
        var index=e.currentTarget.dataset.index
        var wenzhang=that.data.wenzhang
        wenzhang.splice(index,1);//删除指定index记录
        that.setData({
          wenzhang:wenzhang
        })
        app.userInfo.pinglunguode=wenzhang
        var x=that.data.x
        x[index]=0
        that.setData({
          x:x
        })
        wx.showToast({
          title: '删除成功',
          icon:"none"
        })
        db.collection('users').where({
          _id:app.userInfo._id
        }).update({
          data: {
            pinglunguode:_.pull({
              id:_.eq(ssid)
            })
          }
        })
      } else if (res.cancel) {
      console.log('用户点击取消')
      wx.showToast({
        title: '取消删除',
        icon:'none'
      })
      }
      }
      })
  },
  //生命周期函数--监听页面显示
  onShow: function () {
    
  },
  //查看评论的说说
  chakan(ssid){
    //要查看的说说的id
    //console.log(ssid)
    var ssid=ssid.currentTarget.dataset.ssid
    //console.log(ssid)
    
    if(this.data.canshu==false){
      wx.cloud.callFunction({
        name:"look",
        data:{
          id:ssid
        }
      })
    }
    wx.navigateTo({
      url:"../plate2/plate2?id="+ssid+"&fenxiang=false&liuyan=false"
    })
    wx.cloud.callFunction({
      name:"look",
      data:{
        id:ssid,
        type:'ss'
      }
    })
  },
  //滑动删除
  change(e){
    console.log(e.detail.x)
    var x=e.detail.x
    var xx=this.data.xx
    var index=e.currentTarget.dataset.index
    //console.log("index:",index)
    var zs=this.data.wenzhang.length

    if(xx[index]==0 && x<-37.5){
      xx[index]=-75
    }else if(xx[index]==-75 && x>-37.5){
      xx[index]=0
    }
    for(var i=0;i<zs;i++){
      if(i!=index){
        xx[i]=0
      }else{
        console.log("indexqq:",index,i)
      }
    }
    this.setData({
      xx:xx
    })
  },
  change1(e){
    var x=this.data.xx
    this.setData({
      x:x
    })
  }
})