//app.js

App({
  onLaunch: function () {
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
    } else {
      wx.cloud.init({
        // env 参数说明：
        //   env 参数决定接下来小程序发起的云开发调用（wx.cloud.xxx）会默认请求到哪个云环境的资源
        //   此处请填入环境 ID, 环境 ID 可打开云控制台查看
        //   如不填则使用默认环境（第一个创建的环境）
         env: 'cloud1-8gs9khd575d43b12',
        traceUser: true,
      })
    }
    this.shuaxin=false
    this.fenxiang="false"
    this.fxssid=""
    this.glid="9999"
    this.message=[]
    this.globalData = {}
    this.systeminfo=""
    this.loveinfo=""
    this.ssinfo={
      lovenb:"",
      plnb:"",
      looknb:""
    }
    this.userInfo={
      allow:true,
      ban:false,
      msgnb:[0,0],
      online:true,
      _openid:"",
      _id:"",
      wenzhang:[],
      message:[],
      pinglunguode:[],
      userinfo:{
        userphoto:"/images/user/user.png",
        username:"匿名用户",
        anonymous:"",
        isVIP:false,
        login:"未知",
      },
      
    }

    // 初始化登录服务
    const db = wx.cloud.database()
    const that = this  // 保存 this 引用
    this.loginService = {
      // 基础登录验证
      basicLogin: function() {
        return new Promise((resolve, reject) => {
          wx.cloud.callFunction({
            name: 'login',
            data: {}
          }).then(res => {
            const openid = res.result.openid;
            db.collection("users").where({
              _openid: openid
            }).get().then(res => {
              if (res.data.length > 0) {
                that.userInfo = Object.assign(that.userInfo, res.data[0]);  // 使用 that 而不是 this
                resolve(true);
              } else {
                resolve(false);
              }
            }).catch(err => reject(err));
          }).catch(err => reject(err));
        });
      },

      // 完整登录流程
      fullLogin: function() {
        return new Promise((resolve, reject) => {
          wx.getUserProfile({
            desc: '用于完善用户资料',
            success: (res) => {
              let userInfo = res.userInfo;
              if (!that.userInfo.userinfo.login && userInfo) {  // 使用 that 而不是 this
                wx.showLoading({
                  title: '登录中',
                });
                // 先调用云函数获取openid
                wx.cloud.callFunction({
                  name: 'login',
                  data: {}
                }).then(cloudRes => {
                  const openid = cloudRes.result.openid;
                  // 检查是否是管理员
                  db.collection('admin').where({
                    _openid: openid
                  }).get().then(adminRes => {
                    const isAdmin = adminRes.data.length > 0;
                    
                    // 检查用户是否已存在
                    db.collection('users').where({
                      _openid: openid
                    }).get().then(dbRes => {
                      if(dbRes.data.length === 0) {
                        // 新用户，添加到数据库
                        db.collection('users').add({
                          data: {
                            allow: true,
                            ban: false,
                            msgnb: [0,0],
                            online: true,
                            wenzhang: [],
                            message: [],
                            pinglunguode: [],
                            weiguinb: 0,
                            userinfo: {
                              userphoto: userInfo.avatarUrl,
                              username: userInfo.nickName,
                              anonymous: "",
                              isVIP: false,
                              login: true,
                              isAdmin: isAdmin
                            }
                          }
                        }).then(addRes => {   
                          db.collection('users').doc(addRes._id).get().then(userRes => {
                            that.userInfo = Object.assign(that.userInfo, userRes.data);  // 使用 that 而不是 this
                            wx.hideLoading();
                            wx.showToast({
                              title: '登录成功！',
                              icon: 'success'
                            });
                            resolve(true);
                          });
                        });
                      } else {
                        // 老用户，更新信息
                        const userData = dbRes.data[0];
                        userData.userinfo.isAdmin = isAdmin;
                        that.userInfo = Object.assign(that.userInfo, userData);  // 使用 that 而不是 this
                        wx.hideLoading();
                        wx.showToast({
                          title: '登录成功！',
                          icon: 'success'
                        });
                        resolve(true);
                      }
                    });
                  });
                });
              }
            },
            fail: (err) => {
              console.log('登录失败：', err);
              wx.showToast({
                title: '登录失败',
                icon: 'none'
              });
              reject(err);
            }
          });
        });
      }
    };
  },
  //进入小程序就上线
  onShow(){
    //wx.cloud.init({env: cloud.DYNAMIC_CURRENT_ENV})
    var db=wx.cloud.database()
    if(this._id!=""){
      console.log("上线")
      db.collection('users').where({_openid:this._openid}).update({
        data:{
          online:true
        }
      })
    }
  },
  //只在真正退出小程序时才下线
  onHide(){
    //检查是否真的退出小程序
    wx.getEnterOptionsSync().scene === 1001 ? this.handleOffline() : null
  },
  //处理下线逻辑
  handleOffline(){
    var db=wx.cloud.database()
    if(this._id!=""){
      console.log("下线")
      db.collection('users').where({_openid:this._openid}).update({
        data:{
          online:false
        }
      })
    }
  },
  globalData: {
		userInfo: null,
		mapRefresh: false,
		siteRefresh: false,
		schoolRefresh: false,
		introductionRefresh: false
	}
})
