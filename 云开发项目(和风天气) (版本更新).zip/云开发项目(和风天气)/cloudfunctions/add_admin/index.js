// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

// 云函数入口函数
exports.main = async (event, context) => {
  const { name, openid } = event

  try {
    // 检查是否已存在相同_openid的管理员
    const existAdmin = await db.collection('admin')
      .where({
        _openid: openid
      })
      .get()

    if (existAdmin.data.length > 0) {
      return {
        code: 1,
        message: '该OpenID已存在管理员记录'
      }
    }

    // 添加新管理员
    const result = await db.collection('admin').add({
      data: {
        name: name,
        _openid: openid,
        createTime: db.serverDate()
      }
    })

    return {
      code: 0,
      message: '添加成功',
      data: result._id
    }
  } catch (err) {
    console.error('添加管理员失败：', err)
    return {
      code: 1,
      message: '添加失败，请重试'
    }
  }
} 