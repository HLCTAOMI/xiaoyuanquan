// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

// 云函数入口函数
exports.main = async (event, context) => {
  const { _id, name, openid } = event

  try {
    // 检查是否已存在相同_openid的其他管理员
    const existAdmin = await db.collection('admin')
      .where({
        _openid: openid,
        _id: db.command.neq(_id)
      })
      .get()

    if (existAdmin.data.length > 0) {
      return {
        code: 1,
        message: '该OpenID已被其他管理员使用'
      }
    }

    // 更新管理员信息
    const result = await db.collection('admin').doc(_id).update({
      data: {
        name: name,
        _openid: openid,
        updateTime: db.serverDate()
      }
    })

    return {
      code: 0,
      message: '更新成功'
    }
  } catch (err) {
    console.error('更新管理员失败：', err)
    return {
      code: 1,
      message: '更新失败，请重试'
    }
  }
}