// miniprogram/pages/wd/wd.js
const app=getApp()
const db = wx.cloud.database()

Page({
  data: {
    userphoto:"/images/user/user.png",
    username:"梦之泪伤",
    anonymous:"",
    login:"未知",
    isVIP:false,
    wenzhang:[],
    message:[],
    fenxiang:"false",
    isAdmin: false
  },

  // 修改 getUserProfile 方法
  getUserProfile() {
    app.loginService.fullLogin().then(() => {
      this.updateUserInfo();
      // 登录成功后立即检查管理员权限
      this.checkAdminStatus();
    }).catch(err => {
      console.error('登录失败：', err);
    });
  },

  // 修改 weidengluchongshi 方法
  weidengluchongshi() {
    let logined = app.userInfo.userinfo.login;
    if (logined != true) {
      wx.showLoading({
        title: '尝试登录',
      });
      app.loginService.basicLogin().then(success => {
        if (success) {
          this.updateUserInfo();
          // 登录成功后立即检查管理员权限
          this.checkAdminStatus();
        } else {
          this.setData({
            login: false
          });
          app.userInfo.userinfo = Object.assign(app.userInfo.userinfo, {login: false});
          wx.showToast({
            title: '还未授权登录',
            icon: 'none',
            duration: 2000,
          });
        }
        wx.hideLoading();
      }).catch(err => {
        console.error('登录失败：', err);
        wx.hideLoading();
        wx.showToast({
          title: '登录失败',
          icon: 'none'
        });
      });
    } else {
      // 如果已经登录，也检查管理员权限
      this.checkAdminStatus();
    }
  },

  // 检查管理员状态
  checkAdminStatus() {
    if (app.userInfo._openid) {
      db.collection('admin').where({
        _openid: app.userInfo._openid
      }).get().then(res => {
        const isAdmin = res.data.length > 0;
        // 更新全局状态
        app.userInfo.userinfo.isAdmin = isAdmin;
        // 更新页面状态
        this.setData({
          isAdmin: isAdmin
        });
      }).catch(err => {
        console.error('检查管理员状态失败：', err);
      });
    }
  },

  // 更新用户信息到页面
  updateUserInfo() {
    this.setData({
      userphoto: app.userInfo.userinfo.userphoto,
      username: app.userInfo.userinfo.username,
      anonymous: app.userInfo.userinfo.anonymous,
      isVIP: app.userInfo.userinfo.isVIP,
      login: true,
      wenzhang: app.userInfo.wenzhang,
      message: app.userInfo.message,
      isAdmin: app.userInfo.userinfo.isAdmin
    });
  },

  // 检查管理员权限
  checkAdminAccess(e) {
    // 先检查当前状态
    this.checkAdminStatus();
    
    // 使用最新的状态进行判断
    if (app.userInfo.userinfo.isAdmin) {
      wx.navigateTo({
        url: '/pages/admin/admin'
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '您不是管理员',
        showCancel: false
      });
    }
  },

  // 退出登录
  logout() {
    wx.showModal({
      title: '提示',
      content: '确定要退出登录吗？',
      success: (res) => {
        if (res.confirm) {
          // 清除用户信息
          app.userInfo = {
            userinfo: {
              login: false,
              userphoto: "/images/user/user.png",
              username: "未登录",
              anonymous: "",
              isVIP: false,
              isAdmin: false
            }
          }
          
          // 更新页面状态
          this.setData({
            login: false,
            userphoto: "/images/user/user.png",
            username: "未登录",
            anonymous: "",
            isVIP: false,
            isAdmin: false,
            wenzhang: [],
            message: []
          });

          // 清除本地存储
          wx.removeStorageSync('userInfo');

          wx.showToast({
            title: '已退出登录',
            icon: 'success'
          });
        }
      }
    });
  },

  onLoad: function () {
    this.weidengluchongshi();
  },

  onShow: function () {
    this.checkred();
    this.updateUserInfo();
    // 每次显示页面时检查管理员状态
    this.checkAdminStatus();
  },

  onPullDownRefresh: function () {
    if (!this.data.login) {
      wx.stopPullDownRefresh()
      wx.showToast({
        title: '请先登录',
        icon: 'none',
        duration: 800
      })
      return
    }

    var _id = app.userInfo._id
    if (!_id) {
      wx.stopPullDownRefresh()
      wx.showToast({
        title: '登录信息已失效，请重新登录',
        icon: 'none',
        duration: 800
      })
      return
    }

    db.collection('users').doc(_id).get().then((res)=>{
      console.log("取到信息",res.data)
      this.setData({
        userphoto:res.data.userinfo.userphoto,
        username:res.data.userinfo.username,
        anonymous:res.data.userinfo.anonymous,
        isVIP:res.data.userinfo.isVIP,
        login:res.data.userinfo.login,
        wenzhang:res.data.wenzhang,
        message:res.data.message,
      })
      app.userInfo=res.data
      wx.stopPullDownRefresh({})
      wx.showToast({
        title: '刷新成功',
        icon:'none',
        duration:800
      })
    }).catch(err => {
      console.error('刷新失败：', err)
      wx.stopPullDownRefresh()
      wx.showToast({
        title: '刷新失败',
        icon: 'none',
        duration: 800
      })
    })
  },

  checkred() {
    // 刷新消息红点的逻辑
  }
});