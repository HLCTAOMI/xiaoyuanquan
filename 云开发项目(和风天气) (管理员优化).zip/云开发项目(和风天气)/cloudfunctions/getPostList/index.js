const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();

exports.main = async (event) => {
  const { skip = 0, limit = 10 } = event;
  const res = await db.collection('posts')
    .orderBy('createTime', 'desc')
    .skip(skip)
    .limit(limit)
    .get();
  return res.data;
};
