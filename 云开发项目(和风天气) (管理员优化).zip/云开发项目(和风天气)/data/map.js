/* data/map.js */
// 地图相关
module.exports = {
  // 地图部分参数

  // 腾讯位置服务API
  mapKey: "S2OBZ-YP76Q-V4N5N-4TBGN-O3FTH-LNF4E",

  // 学校精确坐标（用于地图定位和获取天气数据）
  longitude: '107.053280',
  latitude: '27.707966',

  // 是否展示 POI 点
  enablepoi: true,
  // 是否显示带有方向的当前定位点
  showLocation: true,
  // 缩放级别
  scale: 16.1,
  // 最小缩放级别，比缩放级别小0.3-0.4为宜
  minscale: 10,

  // 自定义图层
    groundoverlay: {
        // 图层透明度 0-1
        opacity: 0.8,
        // 西南角
        southwest_latitude: 27.703849,
        southwest_longitude: 107.044995,
        // 东北角
        northeast_latitude: 27.713148,
        northeast_longitude: 107.059713,
      },

  // 地图边界
  boundary: {
    // 西南角
    southwest_latitude: 27.700439,
    southwest_longitude: 107.044521,
    // 东北角
    northeast_latitude: 27.716343,
    northeast_longitude: 107.060325,
  },

  // 学校边界
  school_boundary: {
    // 东（学校最东端的 经度）
    east: 107.059028,
    // 西（学校最东端的 经度）
    west: 107.046032,
    // 南（学校最东端的 纬度）
    south: 27.704102,
    // 北（学校最东端的 纬度）
    north: 27.712601,
  },

  // 闭合多边形
  points: [],
}