// pages/admin/manage-admin/manage-admin.js
let db = wx.cloud.database()
let _ = db.command
Page({

  /**
   * 页面的初始数据
   */
  data: {
    sid: 1,
    name: '',
    _openid: '',
    admin_list: [],
    _id: null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    console.log(options)
    if (options.sid) {
      this.setData({
        sid: parseInt(options.sid)
      })
    }
    if (this.data.sid === 2) {
      this.getAdminList()
    }
    this.setData({
      _id: options._id,
      name: options.name,
      _openid: options._openid,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },

  // 获取姓名
  getName(e) {
    this.setData({
      name: e.detail.value
    })
  },

  // 获取openid
  getOpenid(e) {
    this.setData({
      _openid: e.detail.value
    })
  },

  // 获取管理员列表
  getAdminList() {
    db.collection('admin')
      .get()
      .then(res => {
        console.log('success', res)
        this.setData({
          admin_list: res.data
        })
      })
      .catch(err => {
        console.log('fail', err)
      })
  },

  // 添加管理员
  addAdmin() {
    if (!this.data.name || !this.data._openid) {
      wx.showToast({
        title: '请填写完整信息',
        icon: 'none'
      })
      return
    }

    wx.showLoading({
      title: '添加中...'
    })

    wx.cloud.callFunction({
      name: 'add_admin',
      data: {
        name: this.data.name,
        openid: this.data._openid
      }
    }).then(res => {
      wx.hideLoading()
      if (res.result.code === 0) {
        wx.showToast({
          title: '添加成功',
          icon: 'success'
        })
        setTimeout(() => {
          wx.navigateBack()
        }, 1500)
      } else {
        wx.showToast({
          title: res.result.message || '添加失败',
          icon: 'none'
        })
      }
    }).catch(err => {
      wx.hideLoading()
      wx.showToast({
        title: '添加失败',
        icon: 'none'
      })
      console.error('添加管理员失败：', err)
    })
  },

  // 更新管理员
  updateAdmin() {
    if (!this.data.name || !this.data._openid) {
      wx.showToast({
        title: '请填写完整信息',
        icon: 'none'
      })
      return
    }

    wx.showLoading({
      title: '更新中...'
    })

    wx.cloud.callFunction({
      name: 'update_admin',
      data: {
        _id: this.data._id,
        name: this.data.name,
        openid: this.data._openid
      }
    }).then(res => {
      wx.hideLoading()
      if (res.result.code === 0) {
        wx.showToast({
          title: '更新成功',
          icon: 'success'
        })
        setTimeout(() => {
          wx.navigateBack()
        }, 1500)
      } else {
        wx.showToast({
          title: res.result.message || '更新失败',
          icon: 'none'
        })
      }
    }).catch(err => {
      wx.hideLoading()
      wx.showToast({
        title: '更新失败',
        icon: 'none'
      })
      console.error('更新管理员失败：', err)
    })
  },

  // 删除管理员
  removeAdmin() {
    wx.showModal({
      title: '提示',
      content: '确定要删除该管理员吗？',
      success: (res) => {
        if (res.confirm) {
          wx.showLoading({
            title: '删除中...'
          })

          wx.cloud.callFunction({
            name: 'remove_admin',
            data: {
              _id: this.data._id
            }
          }).then(res => {
            wx.hideLoading()
            if (res.result.code === 0) {
              wx.showToast({
                title: '删除成功',
                icon: 'success'
              })
              setTimeout(() => {
                wx.navigateBack()
              }, 1500)
            } else {
              wx.showToast({
                title: res.result.message || '删除失败',
                icon: 'none'
              })
            }
          }).catch(err => {
            wx.hideLoading()
            wx.showToast({
              title: '删除失败',
              icon: 'none'
            })
            console.error('删除管理员失败：', err)
          })
        }
      }
    })
  }
})