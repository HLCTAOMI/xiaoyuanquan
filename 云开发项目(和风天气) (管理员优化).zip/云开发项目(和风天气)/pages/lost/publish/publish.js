Page({
  data: {
    type: 'found', // 默认类型为失物招领
    category: '', // 物品分类
    categoryIndex: 0,
    categories: ['证件', '电子产品', '生活用品', '学习用品', '其他'],
    title: '',
    description: '',
    location: '', // 地点
    locationIndex: 0,
    locations: ['教学楼', '图书馆', '食堂', '宿舍', '操场', '其他'],
    date: '', // 日期
    contact: '',
    reward: '', // 悬赏金额
    urgency: 'normal', // 紧急程度
    images: [],
    isEdit: false, // 是否为编辑模式
    editId: '', // 编辑的信息ID
    submitting: false,
    userInfo: null
  },

  onLoad(options) {
    // 检查登录状态
    this.checkLoginStatus()
    
    // 检查是否为编辑模式
    if (options.isEdit === 'true' && options.id) {
      this.setData({
        isEdit: true,
        editId: options.id
      });
      this.loadLostFoundInfo(options.id);
    }
  },

  // 检查登录状态
  checkLoginStatus() {
    const app = getApp()
    const userInfo = app.userInfo
    
    if (!userInfo || !userInfo.userinfo) {
      // 使用微信登录
      wx.getUserProfile({
        desc: '用于完善用户资料',
        success: (res) => {
          const userInfo = res.userInfo
          // 更新全局用户信息
          app.userInfo = {
            userinfo: userInfo,
            _openid: app.userInfo._openid
          }
          // 更新页面状态
          this.setData({
            userInfo: app.userInfo
          })
        },
        fail: (err) => {
          wx.showToast({
            title: '需要授权才能发布',
            icon: 'none'
          })
          // 返回上一页
          setTimeout(() => {
            wx.navigateBack()
          }, 1500)
        }
      })
    } else {
      this.setData({ userInfo })
    }
  },

  // 加载失物招领信息
  async loadLostFoundInfo(id) {
    wx.showLoading({
      title: '加载中...'
    });

    try {
      const res = await wx.cloud.callFunction({
        name: 'lostAndFound',
        data: {
          action: 'getDetail',
          data: { id }
        }
      });

      if (res.result.code === 0) {
        const info = res.result.data;
        this.setData({
          type: info.type,
          category: info.category,
          categoryIndex: info.categoryIndex,
          title: info.title,
          description: info.description,
          location: info.location,
          locationIndex: info.locationIndex,
          date: info.date,
          contact: info.contact,
          reward: info.reward,
          urgency: info.urgency,
          images: info.images || []
        });
      } else {
        throw new Error(res.result.message);
      }
    } catch (error) {
      console.error('加载信息失败:', error);
      wx.showToast({
        title: '加载信息失败',
        icon: 'none'
      });
    } finally {
      wx.hideLoading();
    }
  },

  // 选择类型
  selectType(e) {
    const type = e.currentTarget.dataset.type;
    this.setData({ type });
  },

  // 选择物品分类
  bindCategoryChange(e) {
    const index = e.detail.value;
    this.setData({
      categoryIndex: index,
      category: this.data.categories[index]
    });
  },

  // 选择地点
  bindLocationChange(e) {
    const index = e.detail.value;
    this.setData({
      locationIndex: index,
      location: this.data.locations[index]
    });
  },

  // 选择日期
  bindDateChange(e) {
    this.setData({
      date: e.detail.value
    });
  },

  // 选择紧急程度
  selectUrgency(e) {
    const urgency = e.currentTarget.dataset.urgency;
    this.setData({ urgency });
  },

  // 选择图片
  chooseImage() {
    wx.chooseImage({
      count: 3 - this.data.images.length,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        // 压缩图片
        const tempFilePaths = res.tempFilePaths;
        const compressedImages = [];
        
        tempFilePaths.forEach(path => {
          wx.compressImage({
            src: path,
            quality: 80,
            success: (res) => {
              compressedImages.push(res.tempFilePath);
              if (compressedImages.length === tempFilePaths.length) {
                this.setData({
                  images: [...this.data.images, ...compressedImages]
                });
              }
            }
          });
        });
      }
    });
  },

  // 预览图片
  previewImage(e) {
    const url = e.currentTarget.dataset.url;
    wx.previewImage({
      current: url,
      urls: this.data.images
    });
  },

  // 删除图片
  deleteImage(e) {
    const index = e.currentTarget.dataset.index;
    const images = this.data.images;
    images.splice(index, 1);
    this.setData({ images });
  },

  // 表单验证
  validateForm(form) {
    const { category, title, description, location, date, contact } = form;
    if (!category) {
      wx.showToast({
        title: '请选择物品分类',
        icon: 'none'
      });
      return false;
    }
    if (!title || !title.trim()) {
      wx.showToast({
        title: '请输入标题',
        icon: 'none'
      });
      return false;
    }
    if (!description || !description.trim()) {
      wx.showToast({
        title: '请输入描述',
        icon: 'none'
      });
      return false;
    }
    if (!location) {
      wx.showToast({
        title: '请选择地点',
        icon: 'none'
      });
      return false;
    }
    if (!date) {
      wx.showToast({
        title: '请选择日期',
        icon: 'none'
      });
      return false;
    }
    if (!contact || !contact.trim()) {
      wx.showToast({
        title: '请输入联系方式',
        icon: 'none'
      });
      return false;
    }
    // 验证手机号格式
    if (!this.validatePhoneNumber(contact)) {
      wx.showToast({
        title: '请输入正确的手机号码',
        icon: 'none'
      });
      return false;
    }
    return true;
  },

  // 验证手机号格式
  validatePhoneNumber(phone) {
    const phoneRegex = /^1[3-9]\d{9}$/;
    return phoneRegex.test(phone);
  },

  // 上传图片到云存储
  async uploadImages() {
    const uploadTasks = this.data.images.map(path => {
      return new Promise((resolve, reject) => {
        // 如果已经是云存储的fileID，直接返回
        if (path.startsWith('cloud://')) {
          resolve(path);
          return;
        }

        // 生成云存储路径
        const cloudPath = `lost_and_found/${Date.now()}-${Math.random().toString(36).substr(2)}.jpg`;
        
        // 上传到云存储
        wx.cloud.uploadFile({
          cloudPath,
          filePath: path,
          success: res => {
            // 返回文件ID
            resolve(res.fileID);
          },
          fail: err => {
            console.error('上传失败：', err);
            reject(err);
          }
        });
      });
    });

    try {
      const fileIDs = await Promise.all(uploadTasks);
      return fileIDs;
    } catch (err) {
      console.error('上传图片失败：', err);
      throw err;
    }
  },

  // 提交表单
  async submitForm(e) {
    const app = getApp()
    
    // 检查登录状态
    if (!app.userInfo || !app.userInfo.userinfo) {
      wx.showToast({
        title: '请先登录',
        icon: 'none'
      })
      return
    }

    const formData = e.detail.value
    const { category, title, description, location, date, contact, reward, urgency } = formData

    // 表单验证
    if (!this.data.type || !category || !title || !description || !location || !date || !contact) {
      wx.showToast({
        title: '请填写必填项',
        icon: 'none'
      })
      return
    }

    // 验证手机号
    if (!/^1[3-9]\d{9}$/.test(contact)) {
      wx.showToast({
        title: '请输入正确的手机号',
        icon: 'none'
      })
      return
    }

    this.setData({ submitting: true })

    try {
      // 上传图片
      let imageUrls = []
      if (this.data.images.length > 0) {
        const uploadTasks = this.data.images.map(filePath => {
          return wx.cloud.uploadFile({
            cloudPath: `lost-found/${Date.now()}-${Math.random().toString(36).substr(2)}.${filePath.match(/\.(\w+)$/)[1]}`,
            filePath
          })
        })
        const uploadResults = await Promise.all(uploadTasks)
        imageUrls = uploadResults.map(res => res.fileID)
      }

      // 调用云函数
      const { result } = await wx.cloud.callFunction({
        name: 'lostAndFound',
        data: {
          action: 'create',
          data: {
            type: this.data.type,
            category,
            title,
            description,
            location,
            date,
            contact,
            reward: reward || 0,
            urgency: urgency || 'normal',
            images: imageUrls,
            status: 'pending',
            _openid: app.userInfo._openid
          }
        }
      })

      if (result.code === 0) {
        wx.showToast({
          title: '发布成功',
          icon: 'success'
        })
        
        // 返回上一页并刷新
        setTimeout(() => {
          const pages = getCurrentPages()
          const prevPage = pages[pages.length - 2]
          if (prevPage) {
            // 直接调用上一页的刷新方法
            prevPage.getLostFoundList()
          }
          wx.navigateBack()
        }, 1500)
      } else {
        throw new Error(result.message || '发布失败')
      }
    } catch (error) {
      wx.showToast({
        title: error.message || '发布失败',
        icon: 'none'
      })
    } finally {
      this.setData({ submitting: false })
    }
  },

  onTitleInput(e) {
    this.setData({
      title: e.detail.value
    });
  }
}); 