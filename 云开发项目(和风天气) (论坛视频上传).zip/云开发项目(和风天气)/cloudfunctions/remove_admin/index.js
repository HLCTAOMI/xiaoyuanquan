// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

// 云函数入口函数
exports.main = async (event, context) => {
  const { _id } = event

  try {
    // 删除管理员
    const result = await db.collection('admin').doc(_id).remove()

    return {
      code: 0,
      message: '删除成功'
    }
  } catch (err) {
    console.error('删除管理员失败：', err)
    return {
      code: 1,
      message: '删除失败，请重试'
    }
  }
}