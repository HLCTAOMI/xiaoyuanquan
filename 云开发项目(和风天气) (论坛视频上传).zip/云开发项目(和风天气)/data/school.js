/* data/school.js */
// 学校相关
module.exports = {
  // 学校官方小程序AppID
  AppID: "wx722dce8061184cba",

  // 学校信息
  school_information: {
    // 学校全称
    school_name_full: "校园圈",
    // 学校英文名
    school_name_English_full: "ZunYi University",
    // 校规校训
    motto: "向学·向善·自律·自强",
    // 学校荣誉
    honor: "遵义师范学院",
    // 建校时间
    build_time: 2001,
    // 办校类型
    school_type: "公办",
    // 院校类型
    institution_type: "综合类",
    // 学校所在地
    location: "贵州・遵义",
    // 学校简介
    text: "遵义师范学院（Zunyi Normal University）坐落于贵州省遵义市，是经教育部批准设立的一所省属本科师范院校。入选教育部高等学校红色经典艺术教育示范基地、贵州省2011协同创新中心、贵州省首批特色文化学校。遵义师范学院的前身是1907年创建的遵义初级师范学堂，1949年，更名为贵州省遵义师范学校。1958年7月，正式成立遵义师范专科学校。1993年6月，升格为遵义师范高等专科学校。2001年，遵义师范高等专科学校升格为遵义师范学院。2008年，遵义师范学院（南白分院）、遵义师范学院（汇川分院）、贵州省南白师范学校并入遵义师范学院。"
  },
}