// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()
const _ = db.command

// 云函数入口函数
exports.main = async (event, context) => {
  const { action, data } = event
  const { OPENID } = cloud.getWXContext()

  switch (action) {
    case 'add':
      return await addLostAndFound(data, OPENID)
    case 'getList':
      return await getLostAndFoundList(data)
    case 'getMyList':
      return await getMyLostAndFoundList(data)
    case 'getDetail':
      return await getLostAndFoundDetail(data)
    case 'update':
      return await updateLostAndFound(data, OPENID)
    case 'delete':
      return await deleteLostAndFound(data, OPENID)
    default:
      return {
        code: -1,
        message: '无效的操作'
      }
  }
}

// 添加失物信息
async function addLostAndFound(data, openid) {
  try {
    const result = await db.collection('lost_and_found').add({
      data: {
        ...data,
        userId: data.userId,
        createTime: db.serverDate(),
        updateTime: db.serverDate()
      }
    })
    return {
      code: 0,
      message: '添加成功',
      data: result._id
    }
  } catch (error) {
    return {
      code: -1,
      message: '添加失败',
      error
    }
  }
}

// 获取失物信息列表
async function getLostAndFoundList(data) {
  const { type, page = 1, pageSize = 10 } = data
  const skip = (page - 1) * pageSize

  try {
    const where = {}
    if (type && type !== 'all') {
      where.type = type
    }

    const [list, total] = await Promise.all([
      db.collection('lost_and_found')
        .where(where)
        .orderBy('createTime', 'desc')
        .skip(skip)
        .limit(pageSize)
        .get(),
      db.collection('lost_and_found')
        .where(where)
        .count()
    ])

    return {
      code: 0,
      message: '获取成功',
      data: {
        list: list.data,
        total: total.total,
        page,
        pageSize
      }
    }
  } catch (error) {
    return {
      code: -1,
      message: '获取失败',
      error: error.message
    }
  }
}

// 获取用户发布的失物信息列表
async function getMyLostAndFoundList(data) {
  const { page = 1, pageSize = 10, userId, isAdmin } = data
  const skip = (page - 1) * pageSize

  try {
    // 构建查询条件
    const where = {
      userId: userId  // 直接使用userId进行查询
    }

    const [list, total] = await Promise.all([
      db.collection('lost_and_found')
        .where(where)
        .orderBy('createTime', 'desc')
        .skip(skip)
        .limit(pageSize)
        .get(),
      db.collection('lost_and_found')
        .where(where)
        .count()
    ])

    return {
      code: 0,
      message: '获取成功',
      data: {
        list: list.data,
        total: total.total,
        page,
        pageSize
      }
    }
  } catch (error) {
    console.error('查询错误:', error)
    return {
      code: -1,
      message: '获取失败',
      error: error.message
    }
  }
}

// 获取失物信息详情
async function getLostAndFoundDetail(data) {
  try {
    const result = await db.collection('lost_and_found')
      .doc(data.id)
      .get()

    return {
      code: 0,
      message: '获取成功',
      data: result.data
    }
  } catch (error) {
    return {
      code: -1,
      message: '获取失败',
      error
    }
  }
}

// 更新失物信息
async function updateLostAndFound(data, openid) {
  const { id, ...updateData } = data

  try {
    // 检查是否是发布者
    const item = await db.collection('lost_and_found')
      .doc(id)
      .get()

    if (item.data._openid !== openid) {
      return {
        code: -1,
        message: '无权限修改'
      }
    }

    await db.collection('lost_and_found')
      .doc(id)
      .update({
        data: {
          ...updateData,
          updateTime: db.serverDate()
        }
      })

    return {
      code: 0,
      message: '更新成功'
    }
  } catch (error) {
    return {
      code: -1,
      message: '更新失败',
      error
    }
  }
}

// 删除失物信息
async function deleteLostAndFound(data, openid) {
  const { id } = data

  try {
    // 检查是否是发布者
    const item = await db.collection('lost_and_found')
      .doc(id)
      .get()

    if (item.data._openid !== openid) {
      return {
        code: -1,
        message: '无权限删除'
      }
    }

    await db.collection('lost_and_found')
      .doc(id)
      .remove()

    return {
      code: 0,
      message: '删除成功'
    }
  } catch (error) {
    return {
      code: -1,
      message: '删除失败',
      error
    }
  }
} 