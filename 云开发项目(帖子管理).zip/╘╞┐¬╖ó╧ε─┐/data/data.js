/* data/data.js */
module.exports = {
  // 和风天气API
  weatherKey: "45d311c2bdb143138c6b49e4f7df76b9",

  // 小程序名称
  miniprogram_name: "校园导航",

  // 相关信息
  information: {
    type: "毕业设计",
    author: "11",
    teacher: "11"
  }
}