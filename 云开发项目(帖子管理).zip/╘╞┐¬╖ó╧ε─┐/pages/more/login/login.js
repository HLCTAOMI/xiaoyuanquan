const app = getApp()

Page({
  /**
   * 页面的初始数据
   */
  data: {
    username: '',
    password: '',
    hasUserInfo: false,
    userInfo: {}
  },
 
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 检查是否已登录
    const userInfo = wx.getStorageSync('userInfo');
    if (userInfo) {
      this.setData({
        hasUserInfo: true,
        userInfo: userInfo
      });
    }
  },
 
  // 输入用户名
  onInputUsername(e) {
    this.setData({
      username: e.detail.value
    });
  },
 
  // 输入密码
  onInputPassword(e) {
    this.setData({
      password: e.detail.value
    });
  },
 
  // 确认登录
  confirmLogin() {
    if (!this.data.username || !this.data.password) {
      wx.showToast({
        title: '请填写完整信息',
        icon: 'none'
      });
      return;
    }

    wx.cloud.callFunction({
      name: 'login',
      data: {
        action: 'login',
        username: this.data.username,
        password: this.data.password
      },
      success: res => {
        if (res.result.code === 0) {
          // 保存用户信息到本地存储和全局状态
          wx.setStorageSync('userInfo', res.result.data);
          app.globalData.userInfo = res.result.data;
          
          this.setData({
            hasUserInfo: true,
            userInfo: res.result.data
          });
          
          wx.showToast({
            title: '登录成功',
            icon: 'success',
            duration: 2000
          });
          
          // 返回上一页
          setTimeout(() => {
            wx.navigateBack();
          }, 2000);
        } else {
          wx.showToast({
            title: res.result.message || '登录失败',
            icon: 'none',
            duration: 2000
          });
        }
      },
      fail: err => {
        console.error('登录失败:', err);
        wx.showToast({
          title: '登录失败，请重试',
          icon: 'none',
          duration: 2000
        });
      }
    });
  },
 
  // 跳转到注册页面
  goToRegister() {
    wx.navigateTo({
      url: '../register/register'
    });
  },
 
  // 修改密码
  reauthorize() {
    wx.showModal({
      title: '修改密码',
      editable: true,
      placeholderText: '请输入新密码',
      success: res => {
        if (res.confirm) {
          const newPassword = res.content;
          wx.cloud.callFunction({
            name: 'login',
            data: {
              action: 'changePassword',
              username: this.data.userInfo.username,
              oldPassword: this.data.password,
              newPassword: newPassword
            },
            success: res => {
              if (res.result.code === 0) {
                wx.showToast({
                  title: '密码修改成功',
                  icon: 'success',
                  duration: 2000
                });
              } else {
                wx.showToast({
                  title: res.result.message || '修改失败',
                  icon: 'none',
                  duration: 2000
                });
              }
            },
            fail: err => {
              console.error('修改密码失败:', err);
              wx.showToast({
                title: '修改失败，请重试',
                icon: 'none',
                duration: 2000
              });
            }
          });
        }
      }
    });
  },
 
  // 退出登录
  exitLogin() {
    wx.showModal({
      title: '提示',
      content: '确定要退出登录吗？',
      success: res => {
        if (res.confirm) {
          wx.removeStorageSync('userInfo');
          this.setData({
            hasUserInfo: false,
            userInfo: {},
            username: '',
            password: ''
          });
          wx.showToast({
            title: '已退出登录',
            icon: 'success',
            duration: 2000
          });
        }
      }
    });
  },

})
