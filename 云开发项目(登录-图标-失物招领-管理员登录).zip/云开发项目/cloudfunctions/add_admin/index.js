// 云函数入口文件
const cloud = require('wx-server-sdk')
const crypto = require('crypto')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
}) // 使用当前云环境

const db = cloud.database()

// 密码加密函数
function encryptPassword(password) {
  return crypto.createHash('sha256').update(password).digest('hex')
}

// 云函数入口函数
exports.main = async (event, context) => {
  const { username, password, name } = event
  const encryptedPassword = encryptPassword(password)

  try {
    // 检查用户名是否已存在
    const existAdmin = await db.collection('admin')
      .where({
        username: username
      })
      .get()

    if (existAdmin.data.length > 0) {
      return {
        code: 1,
        message: '该管理员账号已存在'
      }
    }

    // 创建新管理员
    const result = await db.collection('admin').add({
      data: {
        username,
        password: encryptedPassword,
        name: name || username,
        createTime: db.serverDate(),
        updateTime: db.serverDate(),
        lastLoginTime: db.serverDate(),
        loginCount: 0
      }
    })

    return {
      code: 0,
      message: '添加管理员成功',
      data: {
        _id: result._id
      }
    }
  } catch (err) {
    console.error('添加管理员失败:', err)
    return {
      code: 1,
      message: '添加管理员失败，请稍后重试'
    }
  }
}