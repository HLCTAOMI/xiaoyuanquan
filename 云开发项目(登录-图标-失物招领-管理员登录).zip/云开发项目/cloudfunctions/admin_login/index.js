// 云函数入口文件
const cloud = require('wx-server-sdk')
const crypto = require('crypto')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

// 密码加密函数
function encryptPassword(password) {
  return crypto.createHash('sha256').update(password).digest('hex')
}

// 云函数入口函数
exports.main = async (event, context) => {
  const { username, password } = event
  const encryptedPassword = encryptPassword(password)

  try {
    // 查询管理员
    const admin = await db.collection('admin')
      .where({
        username: username,
        password: encryptedPassword
      })
      .get()

    if (admin.data.length === 0) {
      return {
        code: 1,
        message: '管理员账号或密码错误'
      }
    }

    // 更新登录信息
    await db.collection('admin')
      .doc(admin.data[0]._id)
      .update({
        data: {
          lastLoginTime: db.serverDate(),
          loginCount: db.command.inc(1),
          updateTime: db.serverDate()
        }
      })

    // 登录成功，返回管理员信息（不包含密码）
    const adminInfo = admin.data[0]
    delete adminInfo.password

    return {
      code: 0,
      message: '管理员登录成功',
      data: adminInfo
    }
  } catch (err) {
    console.error('管理员登录失败:', err)
    return {
      code: 1,
      message: '管理员登录失败，请稍后重试'
    }
  }
} 