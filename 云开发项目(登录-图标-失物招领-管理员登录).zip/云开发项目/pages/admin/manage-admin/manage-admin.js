// pages/admin/manage-admin/manage-admin.js
let db = wx.cloud.database()
let _ = db.command
Page({

  /**
   * 页面的初始数据
   */
  data: {
    sid: 1,
    username: '',
    password: '',
    name: '',
    openid: null,
    admin_list: [],
    a_id: 0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    console.log(options)
    if (options.sid) {
      this.setData({
        sid: parseInt(options.sid)
      })
    }
    if (this.data.sid === 2) {
      this.getAdminList()
    }
    this.setData({
      _id: options._id,
      name: options.name,
      openid: options.openid,
    })
    db.collection('admin')
      .get()
      .then(res => {
        console.log('success', res)
        this.setData({
          admin_list: res.data
        })
        let admin_list = this.data.admin_list
        this.setData({
          a_id: admin_list[admin_list.length - 1].a_id + 1
        })
      })
      .catch(err => {
        console.log('fail', err)
      })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },

  // 获取用户名
  getUsername(e) {
    this.setData({
      username: e.detail.value
    })
  },

  // 获取密码
  getPassword(e) {
    this.setData({
      password: e.detail.value
    })
  },

  // 获取姓名
  getName(e) {
    this.setData({
      name: e.detail.value
    })
  },

  getOpenid(e) {
    this.setData({
      openid: e.detail.value
    })
  },

  // 获取管理员列表
  getAdminList() {
    wx.cloud.callFunction({
      name: 'login',
      data: {
        action: 'getAdminList'
      },
      success: res => {
        if (res.result.code === 0) {
          this.setData({
            admin_list: res.result.data
          })
        }
      }
    })
  },

  // 添加管理员
  addAdmin() {
    if (!this.data.username || !this.data.password) {
      wx.showToast({
        title: '请填写完整信息',
        icon: 'none'
      })
      return
    }

    wx.cloud.callFunction({
      name: 'add_admin',
      data: {
        username: this.data.username,
        password: this.data.password,
        name: this.data.name || this.data.username
      },
      success: res => {
        if (res.result.code === 0) {
          wx.showToast({
            title: '添加成功',
            icon: 'success',
            duration: 2000,
            success: () => {
              setTimeout(() => {
                this.back()
              }, 2000)
            }
          })
        } else {
          wx.showToast({
            title: res.result.message || '添加失败',
            icon: 'none'
          })
        }
      },
      fail: err => {
        console.error('添加管理员失败:', err)
        wx.showToast({
          title: '添加失败，请重试',
          icon: 'none'
        })
      }
    })
  },

  // 更新管理员
  updateAdmin() {
    console.log(this.data.name)
    console.log(this.data._id)
    if (this.data.name != null && this.data.name != "" && this.data.openid != null && this.data.openid != "") {
      wx.cloud.callFunction({
          name: 'update_admin',
          data: {
            _id: this.data._id,
            name: this.data.name,
            openid: this.data.openid
          }
        })
        .then(res => {
          console.log('success', res)
          wx.showToast({
            title: '修改成功',
            icon: 'success',
            duration: 2000
          })
          setTimeout(() => {
            this.back()
          }, 1000)
        })
        .catch(err => {
          console.log('fail', err)
        })
    } else {
      wx.showToast({
        title: '请输入名字和openid！',
        icon: 'none',
        duration: 2000
      })
    }
  },

  // 删除管理员
  removeAdmin() {
    var that = this
    wx.showModal({
      title: '提示',
      content: '删除操作不可逆\n请谨慎操作！',
      success(res) {
        if (res.confirm) {
          wx.cloud.callFunction({
              name: 'remove_admin',
              data: {
                _id: that.data._id,
              }
            })
            .then(res => {
              console.log('success', res)
              wx.showToast({
                title: '删除成功',
                icon: 'success',
                duration: 2000
              })
              setTimeout(() => {
                this.back()
              }, 1000)
            })
            .catch(err => {
              console.log('fail', err)
            })
        }
      }
    })
  },

  back() {
    var pages = getCurrentPages();
    var prevPage = pages[pages.length - 2]; // 上一个页面
    // 调用上一个页面对象的方法，重新获取数据
    prevPage.getAdmin();
    wx.navigateBack()
  }
})