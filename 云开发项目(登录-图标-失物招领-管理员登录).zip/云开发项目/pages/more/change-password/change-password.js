Page({
  data: {
    oldPassword: '',
    newPassword: '',
    confirmPassword: ''
  },

  // 输入原密码
  onInputOldPassword(e) {
    this.setData({
      oldPassword: e.detail.value
    });
  },

  // 输入新密码
  onInputNewPassword(e) {
    this.setData({
      newPassword: e.detail.value
    });
  },

  // 输入确认密码
  onInputConfirmPassword(e) {
    this.setData({
      confirmPassword: e.detail.value
    });
  },

  // 确认修改密码
  async confirmChange() {
    const { oldPassword, newPassword, confirmPassword } = this.data;
    const userInfo = wx.getStorageSync('userInfo');
    
    if (!userInfo) {
      wx.showToast({
        title: '请先登录',
        icon: 'none'
      });
      return;
    }

    // 表单验证
    if (!oldPassword || !newPassword || !confirmPassword) {
      wx.showToast({
        title: '请填写完整信息',
        icon: 'none'
      });
      return;
    }

    if (newPassword !== confirmPassword) {
      wx.showToast({
        title: '两次输入的新密码不一致',
        icon: 'none'
      });
      return;
    }

    if (newPassword.length < 6) {
      wx.showToast({
        title: '新密码长度不能少于6位',
        icon: 'none'
      });
      return;
    }

    wx.showLoading({
      title: '修改中...'
    });

    try {
      const res = await wx.cloud.callFunction({
        name: 'users',
        data: {
          action: 'changePassword',
          username: userInfo.username,
          oldPassword,
          newPassword
        }
      });

      if (res.result.code === 0) {
        wx.showToast({
          title: '密码修改成功',
          icon: 'success'
        });

        // 修改成功后返回
        setTimeout(() => {
          wx.navigateBack();
        }, 1500);
      } else {
        throw new Error(res.result.message || '修改失败');
      }
    } catch (error) {
      console.error('修改密码失败:', error);
      wx.showToast({
        title: error.message || '修改失败',
        icon: 'none'
      });
    } finally {
      wx.hideLoading();
    }
  }
}); 