/* data/data.js */
module.exports = {
  // 和风天气API
  weatherKey: "de1f89544449420cb217032e79b9527c",

  // 小程序名称
  miniprogram_name: "校园导航",

  // 相关信息
  information: {
    type: "毕业设计",
    author: "11",
    teacher: "11"
  }
}