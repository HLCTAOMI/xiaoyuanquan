Page({
  data: {
    info: null,
    loading: true,
    error: null
  },

  onLoad(options) {
    if (options.id) {
      // 尝试从缓存中获取数据
      const cachedData = wx.getStorageSync(`lost_detail_${options.id}`);
      if (cachedData) {
        this.setData({
          info: cachedData,
          loading: false
        });
      }
      // 无论是否有缓存，都重新加载数据
      this.loadLostFoundInfo(options.id);
    }
  },

  // 加载失物招领信息
  async loadLostFoundInfo(id) {
    // 如果已经有数据，不显示加载状态
    if (!this.data.info) {
      this.setData({ loading: true, error: null });
    }

    try {
      const res = await wx.cloud.callFunction({
        name: 'lostAndFound',
        data: {
          action: 'getDetail',
          data: { id }
        }
      });

      if (res.result.code === 0) {
        const info = res.result.data;
        // 缓存数据
        wx.setStorageSync(`lost_detail_${id}`, info);
        this.setData({
          info,
          loading: false
        });
      } else {
        throw new Error(res.result.message);
      }
    } catch (error) {
      console.error('加载信息失败:', error);
      this.setData({
        error: error.message || '加载信息失败',
        loading: false
      });
    }
  },

  // 预览图片
  previewImage(e) {
    const { url, urls } = e.currentTarget.dataset;
    wx.previewImage({
      current: url,
      urls: urls
    });
  },

  // 格式化日期
  formatDate(date) {
    if (!date) return '';
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const hour = String(d.getHours()).padStart(2, '0');
    const minute = String(d.getMinutes()).padStart(2, '0');
    return `${year}-${month}-${day} ${hour}:${minute}`;
  },

  onUnload() {
    // 页面卸载时清理缓存
    if (this.data.info) {
      wx.removeStorageSync(`lost_detail_${this.data.info._id}`);
    }
  }
}); 